﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Amazon.S3.Util;

namespace Demo.Services
{
    public class S3Service: IS3Service
    {
        private const string AWS_ACCESS_KEY = "AKIAIFO5AEGGOTWVPKNA";
        private const string AWS_SECRET_KEY = "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";
        private const string BUCKET_NAME = "demo03032021";
        private const string S3_KEY = "Logs.txt";     

        public async Task<string> GetObjectFromAmazons3()
        {
            string responsebody="";
            try
            {
                AmazonS3Client _client = new AmazonS3Client(AWS_ACCESS_KEY, AWS_SECRET_KEY,Amazon.RegionEndpoint.USEast2);
                var request = new GetObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY
                };             
                using (var response = await _client.GetObjectAsync(request))
                using (var responseStream = response.ResponseStream)
                using (var reader = new StreamReader(responseStream))
                {
                    responsebody = reader.ReadToEnd();
                }
            }
            catch (Exception ex)
            {
                responsebody = "Error during reading file";

            }
            return responsebody;
        }

        public async Task<string> WriteContentObjectInAmazons3(string logs)
        {
            string responsebody = "";
            string readresponsebody = "";
            AmazonS3Client _client = new AmazonS3Client(AWS_ACCESS_KEY, AWS_SECRET_KEY, Amazon.RegionEndpoint.USEast2);
            try
            {
                var request = new GetObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY
                };
                using (var response = await _client.GetObjectAsync(request))
                using (var responseStream = response.ResponseStream)
                using (var reader = new StreamReader(responseStream))
                {
                    readresponsebody = reader.ReadToEnd();
                }

                var request1 = new PutObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY,
                    ContentBody= readresponsebody +"\n"+ logs 

                };
                ////DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss.fff tt", System.Globalization.CultureInfo.CurrentCulture) + " " +
                await _client.PutObjectAsync(request1);
                responsebody = "Add record is succesfully";
            }
            catch (Exception ex)
            {
                responsebody = "Error during writing in file";
            }
            return responsebody;
        }

        // public async Task<List<FileList>> ListingObjectsAsync()
        //{
        //    string responsebody = "";
        //    List<FileList> fileList = new List<FileList>();
        //    AmazonS3Client _client = new AmazonS3Client(AWS_ACCESS_KEY, AWS_SECRET_KEY, Amazon.RegionEndpoint.USEast2);
        //    try
        //    {
        //        ListObjectsV2Request request = new ListObjectsV2Request
        //        {
        //            BucketName = BUCKET_NAME,
        //            MaxKeys = 10
        //        };
        //        ListObjectsV2Response response;
        //        do
        //        {
        //            response = await _client.ListObjectsV2Async(request);
        //            // Process the response.
        //            int k = 1;
        //            foreach (S3Object entry in response.S3Objects)
        //            {
        //                FileList objFileList = new FileList();
        //                objFileList.FileId = k;
        //                objFileList.FileName = entry.Key;
        //                fileList.Add(objFileList);
        //                k++;
        //            }                  
        //            request.ContinuationToken = response.NextContinuationToken;
        //        } while (response.IsTruncated);
                
        //    }
        //    catch (AmazonS3Exception amazonS3Exception)
        //    {
        //        Console.WriteLine("S3 error occurred. Exception: " + amazonS3Exception.ToString());
        //        Console.ReadKey();
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine("Exception: " + e.ToString());
        //        Console.ReadKey();
        //    }
        //    return fileList;
        //}

    }

    public interface IS3Service
    {
        Task<string> GetObjectFromAmazons3();
        Task<string> WriteContentObjectInAmazons3(string logs);
    }
}
